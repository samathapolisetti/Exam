abstract class BankAccount {
    String accountNumber;
    double balance;

    public BankAccount(String accountNumber, double balance) {
        this.accountNumber = accountNumber;
        this.balance = balance;
    }

    void deposit(double amount) {
        balance += amount;
        System.out.println("Deposited ₹" + amount + ". New balance: ₹" + balance);
    }

    abstract void withdraw(double amount);
}

interface Transaction {
    void transfer(BankAccount toAccount, double amount);
}

class SavingsAccount extends BankAccount implements Transaction {
    private final double minBalance = 500; 

    public SavingsAccount(String accountNumber, double balance) {
        super(accountNumber, balance);//used to refer parent class
    }

    @Override
    void withdraw(double amount) {
        if (balance - amount >= minBalance) {
            balance -= amount;
            System.out.println("Withdrew ₹" + amount + ". New balance: ₹" + balance);
        } else {
            System.out.println("Withdrawal failed! Minimum balance ₹" + minBalance + " required.");
        }
    }

    @Override
    public void transfer(BankAccount toAccount, double amount) {
        if (balance - amount >= minBalance) {
            balance -= amount;
            toAccount.balance += amount;
            System.out.println("Transferred ₹" + amount + " to " + toAccount.accountNumber);
            System.out.println("New balance: ₹" + balance);
        } else {
            System.out.println("Transfer failed! Minimum balance ₹" + minBalance + " required.");
        }
    }
}

class CurrentAccount extends BankAccount implements Transaction {
    private final double overdraftLimit = 5000; // Overdraft limit

    public CurrentAccount(String accountNumber, double balance) {
        super(accountNumber, balance);
    }

    @Override
    void withdraw(double amount) {
        if (balance - amount >= -overdraftLimit) {
            balance -= amount;
            System.out.println("Withdrew ₹" + amount + ". New balance: ₹" + balance);
        } else {
            System.out.println("Withdrawal failed! Overdraft limit exceeded.");
        }
    }

    @Override
    public void transfer(BankAccount toAccount, double amount) {
        if (balance - amount >= -overdraftLimit) {
            balance -= amount;
            toAccount.balance += amount;
            System.out.println("Transferred ₹" + amount + " to " + toAccount.accountNumber);
            System.out.println("New balance: ₹" + balance);
        } else {
            System.out.println("Transfer failed! Overdraft limit exceeded.");
        }
    }
}

public class MainBank {
    public static void main(String[] args) {
        SavingsAccount savings = new SavingsAccount("SAV123", 5000);
        CurrentAccount current = new CurrentAccount("CUR456", 2000);

        savings.deposit(1000);
        current.withdraw(3000);
        savings.transfer(current, 1500);
        current.transfer(savings, 6000);
    }
}
